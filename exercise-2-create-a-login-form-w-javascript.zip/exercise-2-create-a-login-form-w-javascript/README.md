# Exercise 2: Create a Login Form w/ JavaScript

A Pen created on CodePen.io. Original URL: [https://codepen.io/BryceDominic/pen/bGzjOPr](https://codepen.io/BryceDominic/pen/bGzjOPr).

